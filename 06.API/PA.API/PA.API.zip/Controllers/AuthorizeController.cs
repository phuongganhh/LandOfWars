﻿using PA.API.Models.Authorize;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PA.API.Controllers
{
    public class AuthorizeController : PAController
    {
        // GET: Authorize
        [PAAllowAnonymus]
        public ActionResult Login(LoginAction ActionCmd)
        {
            return JsonExpando(ActionCmd.Execute(CurrentObjectContext));
        }
        [PAAllowAnonymus]
        public ActionResult Register(RegisterAction ActionCmd)
        {
            ActionCmd.MailContent = Server.MapPath("/Content/lib/MailContent.html");
            return JsonExpando(ActionCmd.Execute(CurrentObjectContext));
        }
        
        [PAAllowAnonymus]
        public ActionResult Validate(ValidateAction ActionCmd)
        {
            return JsonExpando(ActionCmd.Execute(CurrentObjectContext));
        }

    }
}