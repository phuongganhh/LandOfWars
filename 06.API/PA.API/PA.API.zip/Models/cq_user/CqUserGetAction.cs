﻿using Entities;
using PA.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PA.API.Models.CqUser
{
    public class CqUserGetAction : CommandBase<dynamic>
    {
        protected override Result<dynamic> ExecuteCore(ObjectContext context)
        {
            return Success(context.getUser<dynamic>());
        }
    }
}