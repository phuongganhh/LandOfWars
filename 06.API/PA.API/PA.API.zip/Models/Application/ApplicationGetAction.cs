﻿using Entities;
using PA.Caching;
using PA.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PA.API.Models.Application
{
    public class ApplicationGetAction : CommandBase<dynamic>
    {
        private List<application> GetApplication(ObjectContext context)
        {
            return context.sql.From("application").Fetch<application>();
            return context.cache.GetOrSet($"GetApplication", () =>
             {
                 return context.db.From("application").Result<application>();
             }, 6 * 60);
        }
        protected override Result<dynamic> ExecuteCore(ObjectContext context)
        {
            var result = this.GetApplication(context).Where(x => x.permission_id == PermissionType.Guest || x.permission_id == context.getPermission).Select(x =>
            {
                x.permission_id = null;
                return x;
            });
            return Success(result);
        }
    }
}