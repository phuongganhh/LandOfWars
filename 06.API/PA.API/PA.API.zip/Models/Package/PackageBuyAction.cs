﻿using Entities;
using PA.Entities;
using PA.Extensions;
using PA.Framework;
using PA.Framework.Enums;
using PA.Framework.Extensions;
using PA.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace PA.API.Models.Package
{
    public class PackageBuyAction : CommandBase
    {
        public long? id { get; set; }
        private package package { get; set; }
        private package GetPackage(ObjectContext context)
        {
            return context.sql.From("package").Where("package.id", this.id).Fetch<package>().FirstOrDefault();
        }
        private Result UpdateAccount(ObjectContext context,account account)
        {
            using(var cmd = new AccountUpdateByIdRepository())
            {
                cmd.data = account;
                return cmd.Execute(context);
            }
        }
        private Result Transfer(ObjectContext context,account acc)
        {
            using(var cmd = new CqBonusInsertRepository())
            {
                cmd.data = new cq_bonus
                {
                    action = Convert.ToInt32(this.package.package_id),
                    id_account = Convert.ToInt32(acc.id)
                };
                return cmd.Execute(context);
            }
        }
        private Result Normal(ObjectContext context)
        {
            var acc = context.getAccount<account>();
            if(acc.money < this.package.price)
            {
                throw new BusinessException("Bạn không đủ tiền, hãy nạp thêm!", HttpStatusCode.NotAcceptable);
            }
            acc.money -= this.package.price.Value;
            if(acc.money < 0)
            {
                throw new BusinessException("Tài khoản của bạn không đủ tiền!", HttpStatusCode.NotAcceptable);
            }
            this.UpdateAccount(context, acc).ThrowIfFail();
            return this.Transfer(context,acc);
        }
        protected override void ValidateCore(ObjectContext context)
        {
            this.package = this.GetPackage(context);
            if(this.package == null)
            {
                throw new BusinessException("Không tìm thấy gói này!", System.Net.HttpStatusCode.NotFound);
            }
            else if(this.package.price == null)
            {
                throw new BusinessException("Gói này hiện không khả dụng!", HttpStatusCode.NotImplemented);
            }
        }
        private Result UpdateUser(ObjectContext context,cq_user user)
        {
            using(var cmd = new CqUserUpdateByIdRepository())
            {
                cmd.data = user;
                return cmd.Execute(context);
            }
        }
        private Result Zp_free(ObjectContext context)
        {
            var user = context.getUser<cq_user>();
            if(user == null)
            {
                throw new BusinessException("Không tìm thấy tài khoản!", System.Net.HttpStatusCode.NotFound);
            }
            if(user.Emoney3 < this.package.price)
            {
                throw new BusinessException("Tài khoản không đủ tiền!", HttpStatusCode.NotAcceptable);
            }
            user.Emoney3 -= Convert.ToInt32(this.package.price.Value);
            if(user.Emoney3 < 0)
            {
                throw new BusinessException("Tài khoản của bạn không đủ tiền!", HttpStatusCode.NotAcceptable);
            }
            this.UpdateUser(context, user).ThrowIfFail();
            return this.Transfer(context,context.getAccount<account>());
        }
        protected override Result ExecuteCore(ObjectContext context)
        {
            this.package = this.GetPackage(context);
            if(this.package.type == PackageType.Normal)
            {
                return this.Normal(context);
            }
            else if(this.package.type == PackageType.Zp_free)
            {
                return this.Zp_free(context);
            }
            throw new BusinessException("Gói này hiện không khả dụng!", HttpStatusCode.NotImplemented);
        }
    }
}